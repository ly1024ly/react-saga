

export const getFile = state => state.files;
export const getCollect = state => state.collects;
export const getIframe = state => state.iframe;
export const getMaintenance = state => state.maintenance;